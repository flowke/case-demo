export default {
  0: {
    id: 0,
    name: "Emma",
    friends: [1,3,5]
  },
  1: {
    id: 1,
    name: "Emily",
    friends: [2,3]
  },
  2: {
    id: 2,
    name: "Mike",
    friends: [5,6,7]
  },
  3: {
    id: 3,
    name: "Madison",
    friends: [9,7]
  },
  4: {
    id: 4,
    name: "Isabella",
    friends: [9, 0, 2, 3]
  },
  5: {
    id: 5,
    name: "Ava",
    friends: [9,4]
  },
  6: {
    id: 6,
    name: "Sophia",
    friends: [9, 0]
  },
  7: {
    id: 7,
    name: "Kaitlyn",
    friends: [9, 0, 3, 1]
  },
  8: {
    id: 8,
    name: "Hannah",
    friends: [1,2,3,4]
  },
  9: {
    id: 9,
    name: "Hailey",
    friends: [2,6,8,0]
  },
}
